<template>
	<view></view>
</template>